<?php
include('../config.php');

// Query untuk mendapatkan pesanan yang belum selesai (Belum Bayar, Proses Verifikasi, Sudah Bayar, Pengiriman)
$query = mysqli_query($config, "SELECT * FROM tb_order WHERE status_order != 'Selesai'");
$data = mysqli_fetch_all($query, MYSQLI_ASSOC);

// Cek aksi dari URL
if (isset($_GET['acc']) || isset($_GET['pending']) || isset($_GET['hapus']) || isset($_GET['konfirmasi'])) {
    $order_id = filter_input(INPUT_GET, 'acc', FILTER_SANITIZE_STRING) 
        ?? filter_input(INPUT_GET, 'pending', FILTER_SANITIZE_STRING) 
        ?? filter_input(INPUT_GET, 'hapus', FILTER_SANITIZE_STRING)
        ?? filter_input(INPUT_GET, 'konfirmasi', FILTER_SANITIZE_STRING);

    if (isset($_GET['acc'])) {
        $action = mysqli_query($config, "UPDATE tb_order SET status_order ='Selesai' WHERE id_order = '" . mysqli_real_escape_string($config, $order_id) . "' AND status_order = 'Pengiriman'");
        if (!$action) {
            echo "Error: " . mysqli_error($config);
            exit;
        }
    } elseif (isset($_GET['pending'])) {
        $action = mysqli_query($config, "UPDATE tb_order SET status_order ='Pending' WHERE id_order = '" . mysqli_real_escape_string($config, $order_id) . "'");
        if (!$action) {
            echo "Error: " . mysqli_error($config);
            exit;
        }
    } elseif (isset($_GET['hapus'])) {
        $action = mysqli_query($config, "DELETE FROM tb_order WHERE id_order = '" . mysqli_real_escape_string($config, $order_id) . "'");
        $action2 = mysqli_query($config, "DELETE FROM tb_keranjang WHERE id_keranjang = '" . mysqli_real_escape_string($config, $order_id) . "'");
        if (!$action || !$action2) {
            echo "Error: " . mysqli_error($config);
            exit;
        }
    } elseif (isset($_GET['konfirmasi'])) {
        $action = mysqli_query($config, "UPDATE tb_order SET status_order = 'Sudah Bayar' WHERE id_order = '" . mysqli_real_escape_string($config, $order_id) . "' AND status_order = 'Proses Verifikasi'");
        if (!$action) {
            echo "Error: " . mysqli_error($config);
            exit;
        }
    }

    // Redirect setelah aksi
    header('Location: ?page=check');
    exit();
}
?>

<div class="container d-flex flex-column justify-content-center">
    <h4 class="text-center mt-3">List Pesanan</h4>

    <div class="table-responsive">
        <table class="table table-striped border">
            <thead class="table-primary">
                <tr>
                    <th>No.</th>
                    <th>Order ID</th>
                    <th>Nama Customer</th>
                    <th>No. Hp</th>
                    <th>Nomor Resi</th>
                    <th>Tanggal Order</th>
                    <th>Grand Total</th>
                    <th>Status</th>
                    <th>Ubah Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($data as $row) : ?>
                    <tr>
                        <?php
                        $tanggal_order = date('d-m-Y', strtotime($row['tanggal_order']));
                        $class = "";
                        if ($row['status_order'] == "Selesai") {
                            $class = "text-success fw-bolder";
                        } else if ($row['status_order'] == "Pending") {
                            $class = "text-warning fw-bolder";
                        } else if ($row['status_order'] == "Pengiriman") {
                            $class = "text-primary fw-bolder";
                        } else if ($row['status_order'] == "Proses Verifikasi") {
                            $class = "text-info fw-bolder";
                        } else if ($row['status_order'] == "Belum Bayar") {
                            $class = "text-danger fw-bolder";
                        }
                        ?>
                        <td><?php echo $no++ . "."; ?></td>
                        <td><?php echo htmlspecialchars($row['id_order']); ?></td>
                        <td><?php echo htmlspecialchars($row['namacust_order']); ?></td>
                        <td><?php echo htmlspecialchars($row['nohp_order']); ?></td>
                        <td><?php echo htmlspecialchars($row['resi_order']); ?></td>
                        <td><?php echo htmlspecialchars($tanggal_order); ?></td>
                        <td>Rp.<?php echo number_format($row['grandtotal_order'], 0, ',', '.'); ?></td>
                        <td class="<?php echo $class ?>"><?php echo htmlspecialchars($row['status_order']); ?></td>
                        <td>
                            <?php if ($row['status_order'] == "Sudah Bayar" || $row['status_order'] == "Pengiriman") : ?>
                                <a href="?page=check&acc=<?php echo urlencode($row['id_order']); ?>" class="btn btn-success mb-1" onclick="return confirm('Anda yakin mengubah status order ini menjadi Selesai?');">Selesai</a>
                                <?php if ($row['status_order'] == "Sudah Bayar") : ?>
                                    <button type="button" class="btn btn-primary mb-1" data-bs-toggle="modal" data-bs-target="#resiModal" data-id="<?php echo $row['id_order']; ?>">
                                        Pengiriman
                                    </button>
                                <?php endif; ?>
                            <?php elseif ($row['status_order'] == "Proses Verifikasi") : ?>
                                <a href="?page=check&konfirmasi=<?php echo urlencode($row['id_order']); ?>" class="btn btn-warning mb-1" onclick="return confirm('Anda yakin ingin mengonfirmasi pembayaran?');">Konfirmasi Pembayaran</a>
                                <button type="button" class="btn btn-secondary mb-1" data-bs-toggle="modal" data-bs-target="#buktiModal" data-id="<?php echo $row['id_order']; ?>" data-bukti="<?php echo urlencode($row['id_order']) . '_' . $row['bukti_bayar']; ?>">
                                    Lihat Bukti
                                </button>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="./generate_pdf.php?orderid=<?php echo urlencode($row['id_order']); ?>" target="_blank" class="btn btn-info mb-1">Cetak PDF</a>
                            <a href="?page=check&hapus=<?php echo urlencode($row['id_order']); ?>" class="btn btn-danger mb-1" onclick="return confirm('Anda yakin menghapus produk ini?');">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal untuk input nomor resi -->
<div class="modal fade" id="resiModal" tabindex="-1" aria-labelledby="resiModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="" method="post">
                <div class="modal-header">
                    <h5 class="modal-title" id="resiModalLabel">Masukkan Nomor Resi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="order_id" id="order_id" value="">
                    <div class="mb-3">
                        <label for="resi" class="form-label">Nomor Resi</label>
                        <input type="text" class="form-control" id="resi" name="resi" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary" name="submitResi">Konfirmasi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal untuk melihat bukti transfer -->
<div class="modal fade" id="buktiModal" tabindex="-1" aria-labelledby="buktiModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="buktiModalLabel">Bukti Transfer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <img src="" id="bukti-img" class="img-fluid" alt="Bukti Transfer">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<?php
// Proses input nomor resi dan update status menjadi Pengiriman
if (isset($_POST['submitResi'])) {
    $order_id = mysqli_real_escape_string($config, filter_input(INPUT_POST, 'order_id', FILTER_SANITIZE_STRING));
    $resi = mysqli_real_escape_string($config, filter_input(INPUT_POST, 'resi', FILTER_SANITIZE_STRING));
    $action = mysqli_query($config, "UPDATE tb_order SET status_order ='Pengiriman', resi_order='$resi' WHERE id_order = '$order_id' AND status_order = 'Sudah Bayar'");
    if (!$action) {
        echo "Error: " . mysqli_error($config);
        exit;
    }
    header('Location: ?page=check');
    exit();
}
?>

<script>
    var resiModal = document.getElementById('resiModal');
    resiModal.addEventListener('show.bs.modal', function(event) {
        var button = event.relatedTarget;
        var orderId = button.getAttribute('data-id');
        var modalOrderInput = resiModal.querySelector('#order_id');
        modalOrderInput.value = orderId;
    });

    var buktiModal = document.getElementById('buktiModal');
    buktiModal.addEventListener('show.bs.modal', function(event) {
        var button = event.relatedTarget;
        var buktiImgSrc = "../assets/bukti_bayar/" + button.getAttribute('data-bukti');
        var buktiImg = buktiModal.querySelector('#bukti-img');
        buktiImg.src = buktiImgSrc;
    });
</script>
