
<?php 
include ('header.php');
?>
<div class="container-fluid justify-content-center align-self-center align-items-center d-flex flex-column">
    <h4 class="m-3">Cara Berbelanja di Note Pro</h4>
<img src="./assets/img/cara_order.png" alt="" style="max-height: 35rem;">
</div>